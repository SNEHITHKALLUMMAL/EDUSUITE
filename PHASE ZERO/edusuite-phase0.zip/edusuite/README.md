# EduSuite

Cloud-based, multi-tenant Education ERP for schools and colleges (Flutter, Node.js/Express, PostgreSQL, Cloudinary).

**Status:** Phase 0 (documentation and repository audit) complete. No application code yet.

Start with `docs/PROJECT_STATE.md`. Requirements are in `docs/source/` (SRS and project specification), tracked in `docs/IMPLEMENTATION_STATUS.md`, and planned in `docs/IMPLEMENTATION_PLAN.md`.
